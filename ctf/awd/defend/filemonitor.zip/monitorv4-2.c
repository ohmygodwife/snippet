#include "md5.h"
#include <errno.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/inotify.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h> 
#include <utime.h> 

#define READ_DATA_SIZE	1024
#define MD5_SIZE		16
#define MD5_STR_LEN		(MD5_SIZE * 2)

char* substr(const char*str, unsigned start, unsigned end)
{
    unsigned n = end - start;
    static char stbuf[256];
    strncpy(stbuf, str + start, n);
    stbuf[n] = 0; //�ִ�������0
    return stbuf;
}

int Compute_file_md5(const char *file_path, char *md5_str)
{
	int i;
	int fd;
	int ret;
	unsigned char data[READ_DATA_SIZE];
	unsigned char md5_value[MD5_SIZE];
	MD5_CTX md5;

	fd = open(file_path, O_RDONLY);
	if (-1 == fd)
	{
		return -1;
	}

	// init md5
	MD5Init(&md5);

	while (1)
	{
		ret = read(fd, data, READ_DATA_SIZE);
		if (-1 == ret)
		{
			strcpy(md5_str,"directory");
			return -1;
		}

		MD5Update(&md5, data, ret);

		if (0 == ret || ret < READ_DATA_SIZE)
		{
			break;
		}
	}

	close(fd);

	MD5Final(&md5, md5_value);

	for(i = 0; i < MD5_SIZE; i++)
	{
		snprintf(md5_str + i*2, 2+1, "%02x", md5_value[i]);
	}
	md5_str[MD5_STR_LEN] = '\0'; // add end

	return 0;
}


int copyfilemodifytime(char *path,char *path2)  
{
	struct stat       statbuf;  
	struct utimbuf   timebuf;  

	if (stat(path, &statbuf) == -1) {  
		printf("stat error for %s\n", path);  
	} else {  
		timebuf.modtime = statbuf.st_mtime;
		timebuf.actime = statbuf.st_atime;
		if (utime(path2, &timebuf) == -1)  
		printf("utime error for %s\n", path);  
	}     
	return 0;  
}


int copyfile(char *path,char *path2){
	char buffer[4096];//���û�������С
	FILE *in,*out;//���������ļ������ֱ������ļ��Ķ�ȡ��д��int len;
	if((in=fopen(path,"r"))==NULL){//��Դ�ļ����ļ���
		printf("Դ�ļ������ڣ�");
		return 1;
	}
	if((out=fopen(path2,"w"))==NULL){//��Ŀ���ļ����ļ���
		printf("����Ŀ���ļ���ʧ�ܣ�");
		return 1;
	}
	int len;//lenΪfread�������ֽڳ�
	while((len=fread(buffer,1,4096,in))>0){//��Դ�ļ��ж�ȡ���ݲ��ŵ��������У��ڶ�������1Ҳ����д��sizeof(char)
		fwrite(buffer,1,len,out);//��������������д��Ŀ���ļ���memset(buffer��0��1024);
	}
	fclose(out);
	fclose(in);
	return 0;
}

unsigned long get_file_size(const char *path)  
{
	unsigned long filesize = -1;
	struct stat statbuff;
	if(stat(path, &statbuff) < 0){
		return filesize;
	}else{
		filesize = statbuff.st_size;
	}
	return filesize;
}

unsigned long get_file_modifytime(const char *path)  
{
	unsigned long modifytime = -1;
	struct stat statbuff;
	if(stat(path, &statbuff) < 0){
		return modifytime;
	}else{
	modifytime = statbuff.st_mtime;
	}
	return modifytime;
}


/* Read all available inotify events from the file descriptor 'fd'.
   wd is the table of watch descriptors for the directories in argv.
   argc is the length of wd and argv.
   argv is the list of watched directories.
   Entry 0 of wd and argv is unused. */

static void
handle_events(int fd, int *wd, int argc, char* argv[])
{
    /* Some systems cannot read integer variables if they are not
       properly aligned. On other systems, incorrect alignment may
       decrease performance. Hence, the buffer used for reading from
       the inotify file descriptor should have the same alignment as
       struct inotify_event. */

	char buf[4096]
	__attribute__ ((aligned(__alignof__(struct inotify_event))));
	const struct inotify_event *event;
	int i;
	ssize_t len;
	char *ptr;
	char filename[200];
	char lastfilename[200];
	char filetype[20];
	char tempstr[200];
	char bakfilemame[200];
	char tempstr2[200];
	time_t now;
	struct tm *tm_now;
	char    datetime[200];
	unsigned long modifytimefile;
	unsigned long modifytimebakfile;
	char md5_str1[MD5_STR_LEN + 1];
	char md5_str2[MD5_STR_LEN + 1];
	char operatemethod[100];
	char *s;
	char *p;
	char *fileext;

	time(&now);
	tm_now = localtime(&now);
	strftime(datetime, 200, "%Y-%m-%d %H:%M:%S", tm_now);

	//printf("======= %s ========\n", datetime);  
	//printf("================================================\n");

	/* Loop while events can be read from inotify file descriptor. */

	for (;;) {

		/* Read some events. */
		
		len = read(fd, buf, sizeof buf);
		if (len == -1 && errno != EAGAIN) {
			perror("read");
		exit(EXIT_FAILURE);
		}

        /* If the nonblocking read() found no events to read, then
           it returns -1 with errno set to EAGAIN. In that case,
           we exit the loop. */

		if (len <= 0)
			break;

	/* Loop over all events in the buffer */

		for (ptr = buf; ptr < buf + len;ptr += sizeof(struct inotify_event) + event->len) {
			event = (const struct inotify_event *) ptr;
			/* Print type of filesystem object */

			if (event->mask & IN_ISDIR)
				strcpy(filetype,"[directory]");
			else{
				strcpy(filetype,"[file]");
				
				//p='\0';
				//strcpy(s,event->name);
				p=strrchr(event->name,'.');

				
				
				/*if (p){*/
				//int pos = p - s;
				//printf("%p",p);
				//fileext=substr(s,pos+1,strlen(s));
				//printf("%s",fileext);
			}


			/* Print the name of the watched directory */

			for (i = 1; i < argc; ++i) {
				if (wd[i] == event->wd) {
					/* printf("%s/", argv[i]); */
					strcpy(filename,argv[i]);
					strcat(filename,"/");
					break;
				}
			}

           /* Print the name of the file */

			if (event->len){
				/* printf("%s", event->name); */
				strcat(filename,event->name);
			}

            /* Print event type */
			if (event->mask & IN_CREATE)
					strcpy(operatemethod,"����");
			if (event->mask & IN_MOVED_TO)
				strcpy(operatemethod,"MOVED_IN"); 
				//printf("MOVED_IN %s \n",filename);
			if (event->mask & IN_CLOSE_WRITE)
				strcpy(operatemethod,"�޸�"); 
			if (event->mask & IN_DELETE)
				strcpy(operatemethod,"ɾ��");
			if (event->mask & IN_MOVED_FROM){
				strcpy(operatemethod,"MOVED_OUT");
				//printf("MOVED_OUT %s \n",filename);
			}
            
			strcpy(bakfilemame,"./bak");
			strcat(bakfilemame,filename);
			modifytimefile=get_file_modifytime(filename);
			modifytimebakfile=get_file_modifytime(bakfilemame);
			strcpy(md5_str1,"");
			strcpy(md5_str2,"");
			Compute_file_md5(filename, md5_str1);
			Compute_file_md5(bakfilemame, md5_str2);
            //printf("filemd5 %s ,bakfilemd5 %s \n",md5_str1,md5_str2);
            //if (modifytimefile==modifytimebakfile && get_file_size(bakfilemame)==get_file_size(filename)){
			if (!strcmp(md5_str1,md5_str2)){
				//printf("%s%s %s ,һ�¡�\n",filetype,operatemethod,filename);
			}
			else{
				if (modifytimebakfile==-1){
					if ( p == NULL ){
						//printf("%s \e[0;33m%s%s ��%s,jjjɾ��\e[0m",datetime,filetype,filename,operatemethod);
						printf("%s \e[0;33m%s%s %s,DELETE\e[0m",datetime,filetype,filename,operatemethod);
						if (event->mask & IN_ISDIR){ //�����Ŀ¼ �����������ļ�������
						}
						else{
						strcpy(tempstr2,"./newfile/");
						strftime(datetime, 200, "%H%M%S_", tm_now);
						strcat(tempstr2,datetime);
						strcat(tempstr2,event->name);
						copyfile(filename,tempstr2);
						}
						if( remove(filename) == 0 ){
						//if(rename(filename,tempstr2) == 0){
							printf("\e[1;32mSSSS\e[0m\n");
						}
						else{
							//perror("remove");
							strcpy(tempstr2,"rm -rf ");
							strcat(tempstr2,filename);
							if( system(tempstr2) == 0 ){
								printf("\e[1;32mrm -rfSSSS\e[0m\n");
							}
							else{
								printf("\e[5;31mFFFF\e[0m\n");
							}
						}
						printf("--------------------------------------\n");
					} 
					else{
						if ( !strcmp(p,".txt") || !strcmp(p,".jpg") || !strcmp(p,".jpeg") || !strcmp(p,".gif") || !strcmp(p,".png") || !strcmp(p,".bmp") ){
							printf("%s \e[0;33m%s%s %s, exp in write\e[0m\e[5;31mno handle\e[0m\n",datetime,filetype,filename,operatemethod);
							printf("--------------------------------------\n");
						}
						else{
							printf("%s \e[0;33m%s%s %s,delete\e[0m",datetime,filetype,filename,operatemethod);
							if (event->mask & IN_ISDIR){ //�����Ŀ¼ �����������ļ�������
							}
							else{
							strcpy(tempstr2,"./newfile/");
							strftime(datetime, 200, "%H%M%S_", tm_now);
							strcat(tempstr2,datetime);
							strcat(tempstr2,event->name);
							copyfile(filename,tempstr2);
							}
							if( remove(filename) == 0 ){
							//if(rename(filename,tempstr2) == 0){
								printf("\e[1;32m�ɹ�\e[0m\n");
							}
							else{
								//perror("remove");
								strcpy(tempstr2,"rm -rf ");
								strcat(tempstr2,filename);
								if( system(tempstr2) == 0 ){
									printf("\e[1;32mrm -rfSSSS\e[0m\n");
								}
								else{
									printf("\e[1;31mFFFF\e[0m\n");
								}
							}
							printf("--------------------------------------\n");
						}
						
						//printf("\n1 %s 1\n",p);
						
					}	
				}
				else{
					if ((event->mask & IN_CLOSE_WRITE)||(event->mask & IN_DELETE)||(event->mask & IN_MOVED_FROM)||(event->mask & IN_MOVED_TO)){
						printf("%s\e[0;34m %s%s %s,restore\e[0m" ,datetime,filetype,filename,operatemethod);
						if (event->mask & IN_ISDIR){  //�ж������Ŀ¼
							strcpy(tempstr2,"cp -R ");
							strcat(tempstr2,bakfilemame);
							strcat(tempstr2," ");
							strcat(tempstr2,filename);
							//printf("%s",tempstr2);
							if( system(tempstr2) == 0 ){
								printf("\e[1;32mcp -RSSSS\e[0m\n");
							}
							else{
								printf("\e[5;31mFFFF\e[0m\n");
							}
						}
						else{  //�ļ����ûָ��ķ�ʽ
							if (copyfile(bakfilemame,filename)==0){
								printf("\e[1;32mSSSS\e[0m\n");
								
								//if (copyfilemodifytime(bakfilemame,filename)==0){
								//	printf("�����޸�ʱ��ɹ�\n");
								//}
							}
							else{
								printf("\e[5;31mFFFF\e[0m\n");
							}
							
						}
						printf("--------------------------------------\n");
					}
				}
			}
		}
	}
}

int
main(int argc, char* argv[])
{
    char buf;
    int fd, i, poll_num;
    int *wd;
    nfds_t nfds;
    struct pollfd fds[2];

    if (argc < 2) {
        printf("Usage: %s PATH [PATH ...]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    printf("Press ENTER key to terminate.\n");

    /* Create the file descriptor for accessing the inotify API */

    fd = inotify_init1(IN_NONBLOCK);
    if (fd == -1) {
        perror("inotify_init1");
        exit(EXIT_FAILURE);
    }

    /* Allocate memory for watch descriptors */

    wd = calloc(argc, sizeof(int));
    if (wd == NULL) {
        perror("calloc");
        exit(EXIT_FAILURE);
    }

    /* Mark directories for events
       - file was opened
       - file was closed */

    for (i = 1; i < argc; i++) {
        wd[i] = inotify_add_watch(fd, argv[i],
                                  IN_CREATE | IN_CLOSE_WRITE | IN_DELETE | IN_MOVED_TO | IN_MOVED_FROM );
        if (wd[i] == -1) {
            fprintf(stderr, "Cannot watch '%s'\n", argv[i]);
            perror("inotify_add_watch");
            exit(EXIT_FAILURE);
        }
    }

    /* Prepare for polling */

    nfds = 2;

    /* Console input */

    fds[0].fd = STDIN_FILENO;
    fds[0].events = POLLIN;

    /* Inotify input */

    fds[1].fd = fd;
    fds[1].events = POLLIN;

    /* Wait for events and/or terminal input */

    printf("Listening for events.\n");
    while (1) {
        poll_num = poll(fds, nfds, -1);
        if (poll_num == -1) {
            if (errno == EINTR)
                continue;
            perror("poll");
            exit(EXIT_FAILURE);
        }

        if (poll_num > 0) {

            if (fds[0].revents & POLLIN) {

                /* Console input is available. Empty stdin and quit */

                while (read(STDIN_FILENO, &buf, 1) > 0 && buf != '\n')
                    continue;
                break;
            }

            if (fds[1].revents & POLLIN) {

                /* Inotify events are available */

                handle_events(fd, wd, argc, argv);
            }
        }
    }

    printf("Listening for events stopped.\n");

    /* Close inotify file descriptor */

    close(fd);

    free(wd);
    exit(EXIT_SUCCESS);
}


